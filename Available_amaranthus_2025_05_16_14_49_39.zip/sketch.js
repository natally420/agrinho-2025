
let gridSize = 40;
let cols, rows;

// Jogadores
let player1, player2;

// Frutas
let fruits = [];
let maxFruits = 10;
let fruitEmojis = ['🍎', '🍌', '🍇', '🍓', '🍉'];

// Tempo
let gameTime = 60 * 1000; // 60 segundos
let startTime;
let gameEnded = false;
let gameStarted = false;

function setup() {
  createCanvas(640, 480);
  cols = floor(width / gridSize);
  rows = floor(height / gridSize);

  // Inicializa jogadores
  player1 = { x: 1, y: 1, score: 0, emoji: '👨‍🌾' };
  player2 = { x: cols - 2, y: rows - 2, score: 0, emoji: '👩‍🌾' };

  // Gera frutas iniciais
  for (let i = 0; i < maxFruits; i++) {
    fruits.push(randomFruitPosition());
  }

  textAlign(CENTER, CENTER);
  textSize(20);
  noStroke();
}

function draw() {
  background(100, 200, 100); // Fundo verde

  if (!gameStarted) {
    // Tela de início
    fill(0);
    textSize(32);
    text("Pressione qualquer tecla para começar!", width / 2, height / 2);
    return;
  }

  if (!gameEnded) {
    // Desenha frutas
    textSize(gridSize * 0.8);
    for (let f of fruits) {
      text(f.emoji, f.x * gridSize + gridSize / 2, f.y * gridSize + gridSize / 2);
    }

    // Desenha jogadores
    drawPlayer(player1);
    drawPlayer(player2);

    // Placar
    fill(0);
    textSize(24);
    text(`Jogador 1: ${player1.score}`, width / 4, 20);
    text(`Jogador 2: ${player2.score}`, (width / 4) * 3, 20);

    // Verifica coleta de frutas
    checkFruitCollection(player1);
    checkFruitCollection(player2);

    // Tempo restante
    let elapsed = millis() - startTime;
    let remaining = max(0, floor((gameTime - elapsed) / 1000));
    text(`Tempo restante: ${remaining}s`, width / 2, 20);

    // Fim do jogo
    if (elapsed >= gameTime) {
      gameEnded = true;
    }
  } else {
    // Tela de fim de jogo
    background(50);
    fill(255);
    textSize(32);
    let winnerText;
    if (player1.score > player2.score) winnerText = "Jogador 1 venceu!";
    else if (player2.score > player1.score) winnerText = "Jogador 2 venceu!";
    else winnerText = "Empate!";
    text(winnerText, width / 2, height / 2);
    textSize(20);
    text("Recarregue a página para jogar novamente.", width / 2, height / 2 + 40);
  }
}

// Desenha um jogador
function drawPlayer(p) {
  textSize(gridSize);
  text(p.emoji, p.x * gridSize + gridSize / 2, p.y * gridSize + gridSize / 2);
}

// Controles do teclado
function keyPressed() {
  if (!gameStarted) {
    gameStarted = true;
    startTime = millis();
    return;
  }

  if (gameEnded) return;

  // Jogador 1 (WASD)
  let nx1 = player1.x;
  let ny1 = player1.y;
  if (key === 'W' || key === 'w') ny1--;
  else if (key === 'S' || key === 's') ny1++;
  else if (key === 'A' || key === 'a') nx1--;
  else if (key === 'D' || key === 'd') nx1++;

  if (insideGrid(nx1, ny1)) {
    player1.x = nx1;
    player1.y = ny1;
  }

  // Jogador 2 (Setas)
  let nx2 = player2.x;
  let ny2 = player2.y;
  if (keyCode === UP_ARROW) ny2--;
  else if (keyCode === DOWN_ARROW) ny2++;
  else if (keyCode === LEFT_ARROW) nx2--;
  else if (keyCode === RIGHT_ARROW) nx2++;

  if (insideGrid(nx2, ny2)) {
    player2.x = nx2;
    player2.y = ny2;
  }
}

// Verifica se um jogador coletou uma fruta
function checkFruitCollection(player) {
  for (let i = fruits.length - 1; i >= 0; i--) {
    if (player.x === fruits[i].x && player.y === fruits[i].y) {
      fruits.splice(i, 1);
      player.score++;
      fruits.push(randomFruitPosition());
      break;
    }
  }
}

// Gera uma posição aleatória para a fruta (evitando jogadores)
function randomFruitPosition() {
  let x, y;
  do {
    x = floor(random(cols));
    y = floor(random(rows));
  } while (
    (x === player1.x && y === player1.y) ||
    (x === player2.x && y === player2.y)
  );
  return { x, y, emoji: random(fruitEmojis) };
}

// Verifica se uma posição está dentro do grid
function insideGrid(x, y) {
  return x >= 0 && x < cols && y >= 0 && y < rows;
}